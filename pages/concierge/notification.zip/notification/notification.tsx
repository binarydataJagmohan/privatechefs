import React from 'react';
import Notification from '../../../components/commoncomponents/Notification';

export default function notification() {
  return (
        <>
            <Notification/>
        </>
  )
}