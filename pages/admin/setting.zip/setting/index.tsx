import React from 'react';
import ChefMyProfile from '../../../components/admin/Setting/Setting';
export default function MyProfile() {
  return (
        <>
            <ChefMyProfile/>
        </>
  )
}
